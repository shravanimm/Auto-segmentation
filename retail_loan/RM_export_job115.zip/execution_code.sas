/* Data preparation project: RLA_APPLICATION (ID 4) */
%dabt_cprm_prj_export_wrapper (project_id_lst = %quote (4));

/* Models: RLA_UD_MODEL (3) and RLA_UD_MODEL2 (4) */
%dabt_cprm_mdl_export_wrapper (model_id_lst = %quote (3,4));